from django.db import migrations

CATEGORIES = [
    ("إلكترونيات", "electronics", 1), ("محافظ وحقائب", "wallets-bags", 2),
    ("مفاتيح", "keys", 3), ("وثائق", "documents", 4),
    ("ملابس وإكسسوارات", "clothing", 5), ("حيوانات", "animals", 6),
    ("أخرى", "other", 99),
]
def seed(apps, schema_editor):
    Category = apps.get_model("core", "Category")
    for name, slug, order in CATEGORIES:
        Category.objects.get_or_create(slug=slug, defaults={"name_ar":name,"sort_order":order})
def unseed(apps, schema_editor):
    apps.get_model("core", "Category").objects.filter(slug__in=[x[1] for x in CATEGORIES]).delete()
class Migration(migrations.Migration):
    dependencies = [("core", "0001_initial")]
    operations = [migrations.RunPython(seed, unseed)]
