from django.urls import path
from django.contrib.auth import views as auth_views
from . import views
from .health import health

urlpatterns = [
    path("healthz/", health, name="health"),
    path("theme/toggle/", views.theme_toggle, name="theme_toggle"),
    path("", views.home, name="home"), path("search/", views.search, name="search"),
    path("accounts/signup/", views.signup, name="signup"), path("accounts/verification-sent/", views.verification_sent, name="verification_sent"), path("accounts/resend-verification/", views.resend_verification, name="resend_verification"), path("accounts/verify/<uidb64>/<token>/", views.verify_email, name="verify_email"), path("accounts/login/", views.login_view, name="login"), path("accounts/logout/", views.logout_view, name="logout"),
    path("accounts/password/reset/", views.password_reset, name="password_reset"), path("accounts/password/reset/done/", auth_views.PasswordResetDoneView.as_view(template_name="registration/password_reset_done.html"), name="password_reset_done"), path("accounts/password/reset/<uidb64>/<token>/", views.SafePasswordResetConfirmView.as_view(), name="password_reset_confirm"), path("accounts/password/reset/complete/", auth_views.PasswordResetCompleteView.as_view(template_name="registration/password_reset_complete.html"), name="password_reset_complete"),
    path("me/", views.dashboard, name="dashboard"), path("reports/new/", views.report_create, name="report_create"), path("reports/<uuid:pk>/", views.report_detail, name="report_detail"), path("reports/<uuid:pk>/edit/", views.report_edit, name="report_edit"), path("reports/<uuid:pk>/close/", views.report_close, name="report_close"), path("reports/<uuid:pk>/contact/", views.contact_start, name="contact_start"), path("reports/<uuid:pk>/abuse/", views.abuse_report, name="abuse_report"), path("private-images/<uuid:pk>/", views.private_image, name="private_image"),
    path("inbox/<uuid:pk>/", views.conversation, name="conversation"), path("inbox/<uuid:pk>/send/", views.message_send, name="message_send"), path("inbox/<uuid:pk>/block/", views.block_user, name="block_user"),
    path("moderation/", views.moderation_queue, name="moderation_queue"), path("moderation/<uuid:pk>/", views.moderation_action, name="moderation_action"),
]
